$('.img').click(function(e){
    $(".dbSelect").hide();
    $(e.target).parent().find('.dbSelect').show();
    $(".btnNext").removeAttr("disabled");
});